package npu.tryit.service;

import java.util.List;

import npu.tryit.entity.Payment;;

public interface PaymentService {


		public long createUser(Payment pay);
	    public Payment updateUser(Payment pay);
	    public List<Payment> getAllPayment();
	   
		public List<Payment> getAllPayment(String paymentDetail);
	
}
