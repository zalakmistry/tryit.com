package npu.tryit.service;

import java.util.List;

import npu.tryit.entity.Dress;

public interface DressService {

	public long createDress(Dress dress);
    public Dress updateDress(Dress dress);
    public List<Dress> getAllDress();
 
	public List<Dress> getAllDress(String dressDetail);
}
