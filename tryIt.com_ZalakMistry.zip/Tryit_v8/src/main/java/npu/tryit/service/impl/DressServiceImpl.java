package npu.tryit.service.impl;

import npu.tryit.dao.DressDAO;
import npu.tryit.entity.Dress;
import npu.tryit.service.DressService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author Tryit.com
 * @version 8.0
 */

@Service
@Transactional
public class DressServiceImpl implements DressService {

	@Override
	public long createDress(Dress dress) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Dress updateDress(Dress dress) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Dress> getAllDress() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Dress> getAllDress(String dressDetail) {
		// TODO Auto-generated method stub
		return null;
	}

}
