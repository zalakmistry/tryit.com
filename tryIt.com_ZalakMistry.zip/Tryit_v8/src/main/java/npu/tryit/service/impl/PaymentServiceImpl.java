package npu.tryit.service.impl;

import npu.tryit.dao.PaymentDAO;
import npu.tryit.entity.Payment;
import npu.tryit.service.PaymentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author Tryit.com
 * @version 8.0
 */

@Service
@Transactional
public class PaymentServiceImpl  implements PaymentService{

	@Override
	public long createUser(Payment pay) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Payment updateUser(Payment pay) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Payment> getAllPayment() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Payment> getAllPayment(String paymentDetail) {
		// TODO Auto-generated method stub
		return null;
	}

}
