package npu.tryit.entity;

public class Payment {
	String cardNumber;
	int expMonth;
	int expYear;
	int cvCode;
	public Payment(String cardNumber, int expMonth, int expYear, int cvCode) {
		super();
		this.cardNumber = cardNumber;
		this.expMonth = expMonth;
		this.expYear = expYear;
		this.cvCode = cvCode;
	}
	public Payment() {
		super();
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public int getExpMonth() {
		return expMonth;
	}
	public void setExpMonth(int expMonth) {
		this.expMonth = expMonth;
	}
	public int getExpYear() {
		return expYear;
	}
	public void setExpYear(int expYear) {
		this.expYear = expYear;
	}
	public int getCvCode() {
		return cvCode;
	}
	public void setCvCode(int cvCode) {
		this.cvCode = cvCode;
	}
	@Override
	public String toString() {
		return "Payment [cardNumber=" + cardNumber + ", expMonth=" + expMonth
				+ ", expYear=" + expYear + ", cvCode=" + cvCode + "]";
	}
	

}
