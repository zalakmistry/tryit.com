package npu.tryit.entity;

public class Dress {
	
	String size;
	String color;
	String material;
	int length;
	boolean machineWash;
	double price;
	
	public Dress() {
		super();
	}
	
	public Dress(String size, String color, String material, int length,
			boolean machineWash, double price) {
		super();
		this.size = size;
		this.color = color;
		this.material = material;
		this.length = length;
		this.machineWash = machineWash;
		this.price = price;
	}

	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public boolean isMachineWash() {
		return machineWash;
	}
	public void setMachineWash(boolean machineWash) {
		this.machineWash = machineWash;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Dress [size=" + size + ", color=" + color + ", material="
				+ material + ", length=" + length + ", machineWash="
				+ machineWash + ", price=" + price + "]";
	}

	
}
