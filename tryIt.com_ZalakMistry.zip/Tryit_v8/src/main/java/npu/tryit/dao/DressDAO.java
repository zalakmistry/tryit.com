package npu.tryit.dao;

import java.util.List;

import npu.tryit.entity.Dress;

public interface DressDAO {

	public long createDress(Dress dress);
    public Dress updateDress(Dress dress);
    public List<Dress> getAllDress();
    
	public List<Dress> getAllDress(String dressDetails);
}
