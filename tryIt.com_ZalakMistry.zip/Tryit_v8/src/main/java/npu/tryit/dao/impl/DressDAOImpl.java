package npu.tryit.dao.impl;

import npu.tryit.dao.DressDAO;
import npu.tryit.entity.Dress;
import npu.tryit.entity.User;
import npu.tryit.util.HibernateUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.security.*;

public class DressDAOImpl implements DressDAO {

	public DressDAOImpl() {
    	System.out.println("dressDAOImpl");
    }
	@Autowired
    private HibernateUtil hibernateUtil;
	
	@Override
	public long createDress(Dress dress) {
		// TODO Auto-generated method stub
		return (Long) hibernateUtil.create(dress);
	}

	@Override
	public Dress updateDress(Dress dress) {
		// TODO Auto-generated method stub
		return hibernateUtil.update(dress);
	}

	
	@Override
	public List<Dress> getAllDress() {
		// TODO Auto-generated method stub
		return hibernateUtil.fetchAll(Dress.class);
	}

	@Override
	public List<Dress> getAllDress(String dressDetails) {
		// TODO Auto-generated method stub
		return null;
	}

}
