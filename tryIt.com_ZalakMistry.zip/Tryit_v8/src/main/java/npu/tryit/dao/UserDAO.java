/**
 * 
 */
package npu.tryit.dao;

import java.util.List;

import npu.tryit.entity.User;

/**
 * @author Tryit.com
 * @version 8.0
 */
public interface UserDAO {
	public long createUser(User user);
    public User updateUser(User user);
    public List<User> getAllUser();
    public User getUser(long id);	
	public List<User> getAllUser(String userName);
}
