package npu.tryit.dao;

import java.util.List;

import npu.tryit.entity.Payment;

public interface PaymentDAO {

	public long createPayment(Payment pay);
    public Payment updatePayment(Payment pay);
    public List<Payment> getAllPayment();
	public List<Payment> getAllUser(String paymentDetails);
}
