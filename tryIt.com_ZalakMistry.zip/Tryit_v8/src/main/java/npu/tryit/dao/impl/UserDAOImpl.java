/**
 * 
 */
package npu.tryit.dao.impl;

import npu.tryit.dao.UserDAO;
import npu.tryit.entity.User;
import npu.tryit.util.HibernateUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.security.*;

//import org.apache.commons.codec.digest.DigestUtils;

/**
 * @author Tryit.com
 * @version 8.0
 */

@Repository
public class UserDAOImpl implements UserDAO {
    
	public UserDAOImpl() {
    	System.out.println("userDAOImpl");
    }
	
	@Autowired
    private HibernateUtil hibernateUtil;

    @Override
    public long createUser(User user) {        
        
      String pas =  user.getPassword();
      
      pas =  md5(pas);
      user.setPassword(pas);
      
      return (Long) hibernateUtil.create(user);
        }
    
    @Override
    public User updateUser(User user) {        
        return hibernateUtil.update(user);
    }
    
    public static String md5(String input) {
		
		String md5 = null;
		
		if(null == input) return null;
		
		try {
			
		//Create MessageDigest object for MD5
		MessageDigest digest = MessageDigest.getInstance("MD5");
		
		//Update input string in message digest
		digest.update(input.getBytes(), 0, input.length());

		//Converts message digest value in base 16 (hex) 
		md5 = new BigInteger(1, digest.digest()).toString(16);

		} catch (NoSuchAlgorithmException e) {

			e.printStackTrace();
		}
		return md5;
	}
    
   
    
    @Override
    public List<User> getAllUser() {        
        return hibernateUtil.fetchAll(User.class);
    }
    
    @Override
    public User getUser(long id) {
        return hibernateUtil.fetchById(id, User.class);
    }

	@SuppressWarnings("unchecked")
	@Override
	public List<User> getAllUser(String userName) { 
		String query = "SELECT e.* FROM user e WHERE e.name like '%"+ userName +"%'";
		List<Object[]> userObjects = hibernateUtil.fetchAll(query);
		List<User> userList = new ArrayList<User>();
		for(Object[] userObject: userObjects) {
			User user = new User();
						
			long id = ((BigInteger) userObject[0]).longValue();		
			String phone = (String) userObject[1];
			
			String fname = (String) userObject[2];
			String lname = (String) userObject[3];
			String emailId = (String) userObject[4];
			String password = (String) userObject[5];
			String address = (String) userObject[6];
			String city = (String) userObject[7];
			String state = (String) userObject[8];
			String country = (String) userObject[9];
			String zip = (String) userObject[10];
			

			user.setId(id);
			user.setFname(fname);
			user.setLname(lname);
			user.setEmailId(emailId);
			user.setPassword(password);
			user.setAddress(address);
			user.setCity(city);
			user.setState(state);
			user.setCountry(country);
			userList.add(user);
		}
		System.out.println(userList);
		return userList;
	}
}