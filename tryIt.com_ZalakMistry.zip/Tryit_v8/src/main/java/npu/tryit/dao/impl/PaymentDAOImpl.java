package npu.tryit.dao.impl;

import npu.tryit.dao.PaymentDAO;
import npu.tryit.dao.UserDAO;
import npu.tryit.entity.Payment;
import npu.tryit.entity.User;
import npu.tryit.util.HibernateUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.security.*;

public class PaymentDAOImpl implements PaymentDAO {

	public PaymentDAOImpl() {
    	System.out.println("paymentDAOImpl");
    }
	
	@Autowired
    private HibernateUtil hibernateUtil;
	
	@Override
	public long createPayment(Payment pay) {
		// TODO Auto-generated method stub
		return (Long) hibernateUtil.create(pay);
	}

	@Override
	public Payment updatePayment(Payment pay) {
		// TODO Auto-generated method stub
		return hibernateUtil.update(pay);
	}

	@Override
	public List<Payment> getAllPayment() {
		// TODO Auto-generated method stub
		return hibernateUtil.fetchAll(Payment.class);
	}

	@Override
	public List<Payment> getAllUser(String paymentDetails) {
		// TODO Auto-generated method stub
		return null;
	}

}
