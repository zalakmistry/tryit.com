package npu.tryit.controller;
import npu.tryit.entity.User;
import npu.tryit.service.UserService;

import org.jboss.logging.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author Tryit.com
 * @version 8.0
 */
@Controller
public class UserController {
	
	private static final Logger logger = Logger.getLogger(UserController.class);
	
	public UserController() {
		System.out.println("UserController()");
	}

    @Autowired
    private UserService userService;

    @RequestMapping("createUser")
    public ModelAndView createUser(@ModelAttribute User user) {
    	logger.info("Creating user. Data: "+ user);
        return new ModelAndView("register");
    }
    
    @RequestMapping("loginUser")
    public ModelAndView loginUser(@ModelAttribute User user) {
        return new ModelAndView("login");
    }
    
    @RequestMapping("home")
    public ModelAndView home(@ModelAttribute User user) {
        return new ModelAndView("index");
    }
    @RequestMapping("shopingBag")
    public ModelAndView shopingBag(@ModelAttribute User user) {
        return new ModelAndView("shoppingbag");
    }
    
    @RequestMapping("aboutus")
    public ModelAndView aboutus(@ModelAttribute User user) {
        return new ModelAndView("aboutus");
    }
    
    @RequestMapping("contactus")
    public ModelAndView contactus(@ModelAttribute User user) {
        return new ModelAndView("contactus");
    }
    
    @RequestMapping("forgotPassword")
    public ModelAndView forgotPassword(@ModelAttribute User user) {
        return new ModelAndView("forgotpassword");
    }
    
    @RequestMapping("terms")
    public ModelAndView terms(@ModelAttribute User user) {
        return new ModelAndView("_terms&condition");
    }
    
    @RequestMapping("categories")
    public ModelAndView categories(@ModelAttribute User user) {
        return new ModelAndView("onepiece");
    }
    
    @RequestMapping("preview")
    public ModelAndView preview(@ModelAttribute User user) {
        return new ModelAndView("details");
    }
    @RequestMapping("addToCart")
    public ModelAndView addToCart(@ModelAttribute User user) {
        return new ModelAndView("shoppingbag");
    }
    
    @RequestMapping("checkOut")
    public ModelAndView checkOut(@ModelAttribute User user) {
        return new ModelAndView("payment");
    }
    
    @RequestMapping("confirm")
    public ModelAndView payment(@ModelAttribute User user) {
        return new ModelAndView("confirm payment");
    }
    
    @RequestMapping("saveUser")
    public ModelAndView saveUser(@ModelAttribute User user) {
    	logger.info("Saving the User Data : "+user);
        if(user.getId() == 0){ // if user id is 0 then creating the user other updating the user
            userService.createUser(user);
        } else {
            userService.updateUser(user);
        }
        return new ModelAndView("welcome");
    }
    

    @RequestMapping(value = {"getAllUser", "/"})
    public ModelAndView getAllUser() {
    	logger.info("Getting the all users.");
        List<User> userList = userService.getAllUser();
        return new ModelAndView("index", "index", userList);
    }

}